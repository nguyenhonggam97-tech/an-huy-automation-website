
import {Routes,Route} from 'react-router-dom'
import Layout from './components/Layout'
import Home from './pages/Home'
import Services from './pages/Services'
import Projects from './pages/Projects'
import Contact from './pages/Contact'
export default function App(){
return <Layout>
<Routes>
<Route path="/" element={<Home/>}/>
<Route path="/services" element={<Services/>}/>
<Route path="/projects" element={<Projects/>}/>
<Route path="/contact" element={<Contact/>}/>
</Routes>
</Layout>}
