
export default function Home(){return <main>
<section className="bg-cyan-100 py-24 text-center">
<h1 className="text-5xl font-bold text-blue-900">Giải pháp tự động hóa và quản lý chất lượng</h1>
<p className="mt-4">Tự động hóa • Điện điện tử • Đào tạo • ISO</p>
</section>
<section className="max-w-6xl mx-auto p-10 grid md:grid-cols-4 gap-5">
{['PLC/SCADA','Điện công nghiệp','Đào tạo','ISO'].map(x=><div className='shadow rounded-xl p-6' key={x}><h3 className='font-bold'>{x}</h3></div>)}
</section></main>}
