
import {Link} from 'react-router-dom'
export default function Layout({children}){
return <>
<header className="sticky top-0 bg-white shadow z-10">
<div className="max-w-6xl mx-auto flex justify-between p-4">
<div className="font-bold text-blue-900">AN HUY AUTOMATION</div>
<nav className="flex gap-4">
<Link to="/">Trang chủ</Link>
<Link to="/services">Dịch vụ</Link>
<Link to="/projects">Dự án</Link>
<Link to="/contact">Liên hệ</Link>
</nav>
</div></header>
{children}
<footer className="bg-slate-900 text-white p-10 mt-12 text-center">Công ty TNHH MTV Dịch vụ và Kỹ thuật An Huy</footer>
</>
}
