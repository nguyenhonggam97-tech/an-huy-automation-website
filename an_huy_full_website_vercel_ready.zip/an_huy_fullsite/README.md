
Setup:
npm install
npx tailwindcss init -p
npm run dev

Deploy Vercel:
1. Push to GitHub
2. Import project to Vercel
3. Framework: Vite
4. Deploy
